

const scriptsInEvents = {

	async E_sys_Event32_Act2(runtime, localVars)
	{
		parent.showRewardAd();
	},

	async E_game_Event156_Act1(runtime, localVars)
	{
		console.log("press player")
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
